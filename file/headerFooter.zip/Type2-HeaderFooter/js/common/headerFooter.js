$(document).ready(function () {
    //解決點擊延遲
    FastClick.attach(document.body);

    //選單滾動
    //Header-Type2
    var lastScrollTop;
    navbar = document.getElementById('header');
    var w = window.innerWidth;
    window.addEventListener('scroll', function () {
        var scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        if (scrollTop <= 0) {
            navbar.style.top = '0';
        } else if (scrollTop > lastScrollTop) {
            if (w < 577) {
                navbar.style.top = '-59px';
            }else{
                navbar.style.top = '-70px';
            }
        } else {
            if (w < 577) {
                navbar.style.top = '-59px';
            }else{
                navbar.style.top = '-70px';
            }
        }
        lastScrollTop = scrollTop;
    });
    $('a[href*=\\#]:not([href=\\#])').click(function() {
        var target = $(this.hash);
        if (w < 577){
            $('html, body').animate({
                scrollTop: $(target).offset().top-60
            }, 500);
        }else{
            $('html, body').animate({
                scrollTop: $(target).offset().top-120
            }, 500);
        }
   
        return false;
    })


    //gotop        
    var float_btn = $('.float_btn');
    var gotop = $('#gotop');
    gotop.click(function () {
        $('html,body').animate({
            scrollTop: 0
        }, 500);
    });
    $(window).scroll(function () {
        if ($(this).scrollTop() > 200) {
            float_btn.fadeIn();
        } else {
            float_btn.stop().fadeOut();
        }
    });
    if ($(window).width() < 769) {

        $(window).scroll(function () {
            //最後一頁scrollTop=body-window，50是預留空間
            last = $("body").height() - $(window).height() - 200
            if ($(window).scrollTop() >= last) {
                $(".float_action_group").hide()
            } else {
                $(".float_action_group").show()
            }

        })
    }
})